mobile-cloud-videoconf
======================

The goal of this project is to develop real time communication application  in the MobiCloud environment. The WebRTC application needs to be run on a Drupal Web  Server as a module or a content page. Users of the website shall be able to use the WebRTC  application to chat with each other and share computer screen with each other. Group chatting  and group screen sharing is also required, which meaning users can set up a group chatting and  share one computer screen to multiple user at same time (similar to Google Hangouts)
